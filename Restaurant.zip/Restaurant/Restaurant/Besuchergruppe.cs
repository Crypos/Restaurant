﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public enum Besucherstatus
    {
        kommend,
        gehend,
        sitzend,
        abgewiesen
    }

    public class Besuchergruppe
    {
        public byte Anzahl { get; private set; }
        public Besucherstatus Besucherstatus {get;set;}
        public Tisch ZugewiesenerTisch { get; set; }

        public Besuchergruppe(byte Anzahl)
        {
            this.Anzahl = Anzahl;
            this.Besucherstatus = Besucherstatus.kommend;
        }

        public void BesuchergruppeHinsetzen ()
        {
            Besucherstatus = Besucherstatus.sitzend;
        }

        public void BesuchergruppePlatzieren(Tisch tisch)
        {
            Besucherstatus = Besucherstatus.kommend;
            ZugewiesenerTisch = tisch;
        }
    

        public void BesuchergruppeAufstehen()
        {
            Besucherstatus = Besucherstatus.gehend;
        }
    }
}
