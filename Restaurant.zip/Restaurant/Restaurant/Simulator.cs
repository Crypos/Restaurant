﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Simulator
    {
        private Random rnd = new Random();

        private Restaurant restaurant;
        private byte aufstehwahrscheinlichkeit;


        public Simulator(Restaurant restaurant, byte aufstehwahrscheinlichkeit)
        {
            this.restaurant = restaurant;
            this.aufstehwahrscheinlichkeit = aufstehwahrscheinlichkeit;
        }

        public void NaechsteRunde()
        {
            // Aufräumen nach der letzten Runde
            BesuchergruppenEntfernen();

            // Aufgestandene Gruppen gehen, wartende Gruppen setzen sich
            BesucherstatusAktualisieren();

            // Zufällig generierte Gruppen an Tische platzieren
            NeueBesucherErzeugen((byte)rnd.Next(0, 255));
        }

        private void BesucherstatusAktualisieren()
        {
            foreach (var besuchergruppe in restaurant.Besuchergruppen)
            {
                switch (besuchergruppe.Besucherstatus)
                {
                    case Besucherstatus.kommend:
                        {
                            besuchergruppe.BesuchergruppeHinsetzen();
                            break;
                        }
                    case Besucherstatus.sitzend:
                        {
                            if (rnd.Next(1, 100) <= aufstehwahrscheinlichkeit)
                                besuchergruppe.BesuchergruppeAufstehen();
                            break;
                        }
                }
            }
        }

        private void BesuchergruppenEntfernen()
        {
            restaurant.Besuchergruppen.RemoveAll(besuchergruppe => besuchergruppe.Besucherstatus == Besucherstatus.gehend
                                                                   || besuchergruppe.Besucherstatus == Besucherstatus.abgewiesen);
        }


        private void NeueBesucherErzeugen(byte anzahlGruppen)
        {
            for (int i = 1; i <= anzahlGruppen; i++)
            {
                var besuchergruppe = new Besuchergruppe((byte)rnd.Next(1, 255));

                restaurant.RestaurantBetreten(besuchergruppe);
            }
        }
    }
    
}
