﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Konsolenausgabe
    {
        private StringBuilder ausgabeAbgewieseneGruppe;
        private StringBuilder ausgabeTischbelegung;

        public Konsolenausgabe()
        {
            ausgabeAbgewieseneGruppe = new StringBuilder();
            ausgabeAbgewieseneGruppe.AppendLine("Abgewiesene Gruppen: ");

            ausgabeTischbelegung = new StringBuilder();
            ausgabeTischbelegung.AppendLine("Aktuelle Sitzverteilung: ");
        }

        public void AbgewieseneGruppeHinzufuegen(int Anzahl)
        {
            ausgabeAbgewieseneGruppe.Append(Anzahl + "\t");
        }

        public void TischHinzufügen(int anzahlPlätze, int sitzendePersonen, int wartendePersonen, int gehendePersonen)
        {
            ausgabeTischbelegung.AppendFormat("Anzahl Plätze: {0}, belegte Plätze: {1}, Anzahl wartende Personen: {2}, Anzahl gehende Personen: {3}", anzahlPlätze, sitzendePersonen, wartendePersonen, gehendePersonen);
            ausgabeTischbelegung.AppendLine();
        }

        public void Ausgabe()
        {
            Console.WriteLine(ausgabeAbgewieseneGruppe.AppendLine().Append(ausgabeTischbelegung));
        }
        
    }
}
