﻿using System;

namespace Restaurant
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var restaurant = new Restaurant((byte)new Random().Next(0,255));
                var simulator = new Simulator(restaurant, (byte)new Random().Next(0, 100));

                Console.WriteLine("Beliebige Taste zum Fortsetzen, 'q' zum beenden");

                while (Console.ReadKey(false).KeyChar != 'q')
                {
                    simulator.NaechsteRunde();
                    new Statusausgabe(restaurant).StatusAusgeben();
                    Console.WriteLine("Beliebige Taste zum Fortsetzen, 'q' zum beenden");
                }

                Console.WriteLine("Simulation beendet");
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fehler");
                Environment.Exit(0);
            }
        }
    }
}
