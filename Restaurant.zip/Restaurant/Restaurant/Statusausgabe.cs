﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Statusausgabe
    {
        private Konsolenausgabe konsolenausgabe;

        public Statusausgabe(Restaurant restaurant)
        {
            konsolenausgabe = new Konsolenausgabe();

            foreach (var gruppe in restaurant.Besuchergruppen.Where(besuchergruppe => besuchergruppe.Besucherstatus == Besucherstatus.abgewiesen))
                konsolenausgabe.AbgewieseneGruppeHinzufuegen(gruppe.Anzahl);

            foreach (var tisch in restaurant.Tische)
            {
                var wartendePersonen = AnzahlBestimmen(restaurant, tisch, Besucherstatus.kommend);
                var gehendePersonen = AnzahlBestimmen(restaurant, tisch, Besucherstatus.gehend);
                var sitzendePersonen = AnzahlBestimmen(restaurant, tisch, Besucherstatus.sitzend);

                konsolenausgabe.TischHinzufügen(tisch.AnzahlStühle, sitzendePersonen, wartendePersonen, gehendePersonen);
            }
        }

        private int AnzahlBestimmen(Restaurant restaurant, Tisch tisch, Besucherstatus besucherstatus)
        {
            return restaurant.Besuchergruppen.Where(besuchergruppe => besuchergruppe.ZugewiesenerTisch == tisch && besuchergruppe.Besucherstatus == besucherstatus)
                                                .Sum(besuchgeruppe => besuchgeruppe.Anzahl);
        }

        public void StatusAusgeben()
        {
            konsolenausgabe.Ausgabe();
        }
    }
}
