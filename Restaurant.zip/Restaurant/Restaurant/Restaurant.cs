﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Restaurant
    {
        public List<Tisch> Tische {get;set;}
        public List<Besuchergruppe> Besuchergruppen { get; set; }

        public Restaurant (byte Tischzahl)
        {
            Random rand = new Random();
            Tische = new List<Tisch>();

            for (byte i = 1; i <= Tischzahl; i++)
                Tische.Add(new Tisch((byte)rand.Next(0,255)));

            Besuchergruppen = new List<Besuchergruppe>();
        }

        /// <summary>
        /// Berechnet die verfügbaren Plätze an dem übergebenen Tisch
        /// </summary>
        /// <param name="tisch"></param>
        /// <returns></returns>
        public byte FreiePlätze(Tisch tisch)
        {
            var belegteStühle = Besuchergruppen.Where(gruppe => gruppe.ZugewiesenerTisch == tisch
                                                                && (gruppe.Besucherstatus == Besucherstatus.sitzend
                                                                    || gruppe.Besucherstatus == Besucherstatus.kommend))
                                              .Sum(gruppe => gruppe.Anzahl);

            return (byte)(tisch.AnzahlStühle - belegteStühle);
        }

        /// <summary>
        /// Berechnet die freien Plätze an einem Tisch
        /// </summary>
        /// <param name="tisch"></param>
        /// <returns></returns>
        public byte BelegtePlätze(Tisch tisch)
        {
            return (byte)(tisch.AnzahlStühle - FreiePlätze(tisch));
        }

        /// <summary>
        /// Gibt zurück ob ein Tisch leer ist
        /// </summary>
        /// <param name="tisch"></param>
        /// <returns></returns>
        public bool LeererTisch(Tisch tisch)
        {
            return FreiePlätze(tisch) == tisch.AnzahlStühle;
        }

        public void RestaurantBetreten(Besuchergruppe besuchergruppe)
        {
            var freierTisch = Tische.FirstOrDefault(tisch => LeererTisch(tisch) && tisch.AnzahlStühle >= besuchergruppe.Anzahl);

            if (freierTisch == null)
                freierTisch = Tische.FirstOrDefault(tisch => FreiePlätze(tisch) >= besuchergruppe.Anzahl);

            if (freierTisch != null)
            {
                besuchergruppe.BesuchergruppePlatzieren(freierTisch);
            }
            else
                besuchergruppe.Besucherstatus = Besucherstatus.abgewiesen;

            Besuchergruppen.Add(besuchergruppe);
        }
    }
}
